package com.stackroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRest {

	public static void main(String[] args) {
		SpringApplication.run(UserRest.class, args);
	}
}

