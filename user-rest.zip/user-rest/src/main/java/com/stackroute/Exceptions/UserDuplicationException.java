package com.stackroute.Exceptions;

public class UserDuplicationException extends Exception {
}
