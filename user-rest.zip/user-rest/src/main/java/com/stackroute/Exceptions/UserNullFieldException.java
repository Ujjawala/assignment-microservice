package com.stackroute.Exceptions;

public class UserNullFieldException extends  Exception {


}
