package com.stackroute.Exceptions;

public class UserNotFoundException extends Exception {
}
