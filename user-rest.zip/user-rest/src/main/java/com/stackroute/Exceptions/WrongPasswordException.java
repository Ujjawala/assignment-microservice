package com.stackroute.Exceptions;

public class WrongPasswordException extends Exception {
}
